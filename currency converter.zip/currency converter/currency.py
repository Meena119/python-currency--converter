import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkcalendar import DateEntry
from PIL import Image, ImageTk
import requests
from io import BytesIO
import csv
import pycountry
import geocoder
from datetime import datetime, timedelta

# === Auto-detect system currency using IP ===
def get_default_currency():
    try:
        country_code = geocoder.ip('me').country
        return country_currency_map.get(country_code, 'USD')
    except:
        return 'USD'

# === Generate full currency names for dropdown ===
def get_currency_display_list():
    display_list = []
    for curr in pycountry.currencies:
        display_list.append(f"{curr.alpha_3} - {curr.name}")
        currency_fullname_map[curr.alpha_3] = curr.name
    return sorted(display_list)

# === Map currency code to country for flags ===
country_currency_map = {
    'US': 'USD', 'IN': 'INR', 'GB': 'GBP', 'JP': 'JPY', 'AU': 'AUD',
    'CA': 'CAD', 'CH': 'CHF', 'CN': 'CNY', 'EU': 'EUR'
}
currency_country_map = {v: k for k, v in country_currency_map.items()}
currency_fullname_map = {}

# === Fetch flag from currency code ===
def fetch_flag(currency_code):
    country_code = currency_country_map.get(currency_code, 'US').lower()
    url = f"https://flagcdn.com/48x36/{country_code}.png"
    try:
        response = requests.get(url)
        img = Image.open(BytesIO(response.content))
        return ImageTk.PhotoImage(img)
    except:
        return None

# === Parse selected dropdown value to get currency code ===
def parse_currency_code(selected_text):
    return selected_text.split(" - ")[0]

# === Get exchange rate ===
def get_rate(from_curr, to_curr, date='latest'):
    if from_curr == to_curr:
        return 1.0
    try:
        url = f"https://api.frankfurter.app/{date}?from={from_curr}&to={to_curr}"
        response = requests.get(url)
        data = response.json()
        if "rates" in data and to_curr in data["rates"]:
            return data["rates"][to_curr]
        else:
            return None
    except:
        return None

# === Update flag images ===
def update_flags(*args):
    for combo, label in [(combo_from, flag_from), (combo_to, flag_to)]:
        code = parse_currency_code(combo.get())
        img = fetch_flag(code)
        if img:
            label.config(image=img)
            label.image = img

# === Perform conversion ===
def convert():
    try:
        amount = float(entry_amount.get())
        from_curr = parse_currency_code(combo_from.get())
        to_curr = parse_currency_code(combo_to.get())
        date = cal.get_date().strftime("%Y-%m-%d")
        rate = get_rate(from_curr, to_curr, date)

        if rate is None:
            messagebox.showerror("API Error", "Could not fetch exchange rate. Please try a different currency or date.")
            return

        result = round(amount * rate, 2)
        label_result.config(text=f"{amount} {from_curr} = {result} {to_curr} on {date}")
        conversion_history.append([amount, from_curr, result, to_curr, date])
    except ValueError:
        messagebox.showerror("Input Error", "Enter a valid number.")

# === Save history to CSV ===
def save_csv():
    if not conversion_history:
        messagebox.showinfo("No Data", "No conversions to save.")
        return
    file = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
    if file:
        with open(file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Amount', 'From', 'Converted', 'To', 'Date'])
            writer.writerows(conversion_history)
        messagebox.showinfo("Saved", f"Saved to {file}")

# === Switch From/To currencies ===
def switch_currencies():
    from_value = combo_from.get()
    to_value = combo_to.get()
    combo_from.set(to_value)
    combo_to.set(from_value)
    update_flags()

# === GUI SETUP ===
window = tk.Tk()
window.title("Enhanced Currency Converter")
window.geometry("550x470")
window.resizable(False, False)
window.configure(bg="#f5f5f5")

tk.Label(window, text="Currency Converter", font=("Arial", 18, "bold"), bg="#f5f5f5").pack(pady=10)

frame = tk.Frame(window, bg="#f5f5f5")
frame.pack(pady=10)

tk.Label(frame, text="Amount:", bg="#f5f5f5").grid(row=0, column=0, sticky="e")
entry_amount = tk.Entry(frame, width=18)
entry_amount.grid(row=0, column=1, columnspan=2, padx=10)

tk.Label(frame, text="From:", bg="#f5f5f5").grid(row=1, column=0, sticky="e")
combo_from = ttk.Combobox(frame, values=get_currency_display_list(), width=30)
combo_from.grid(row=1, column=1)
flag_from = tk.Label(frame, bg="#f5f5f5")
flag_from.grid(row=1, column=2)

tk.Label(frame, text="To:", bg="#f5f5f5").grid(row=2, column=0, sticky="e")
combo_to = ttk.Combobox(frame, values=get_currency_display_list(), width=30)
combo_to.grid(row=2, column=1)
flag_to = tk.Label(frame, bg="#f5f5f5")
flag_to.grid(row=2, column=2)

tk.Button(frame, text="🔁 Switch", command=switch_currencies, bg="#dddddd").grid(row=3, column=1, pady=5)

tk.Label(frame, text="Date:", bg="#f5f5f5").grid(row=4, column=0, sticky="e")
cal = DateEntry(frame, width=12, background='darkblue', foreground='white', borderwidth=2)
cal.grid(row=4, column=1, pady=5)

# Result + Buttons
tk.Button(window, text="Convert", command=convert, bg="#4caf50", fg="white", width=15).pack(pady=10)
label_result = tk.Label(window, text="", font=("Arial", 13), bg="#f5f5f5")
label_result.pack()

tk.Button(window, text="💾 Save to CSV", command=save_csv, bg="#2196f3", fg="white").pack(pady=5)

# Initial Setup
default_curr = get_default_currency()
combo_from.set(f"{default_curr} - {currency_fullname_map[default_curr]}")
combo_to.set("INR - Indian Rupee")

conversion_history = []
update_flags()
combo_from.bind("<<ComboboxSelected>>", update_flags)
combo_to.bind("<<ComboboxSelected>>", update_flags)

window.mainloop()
